package com.openss.launcher;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.content.res.Configuration;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 11, 32);
    private final int PANEL = Color.rgb(28, 29, 69);
    private final int PANEL2 = Color.rgb(39, 39, 91);
    private final int PURPLE = Color.rgb(126, 75, 255);
    private final int TEXT = Color.rgb(245, 243, 255);
    private final int MUTED = Color.rgb(183, 178, 224);
    private LinearLayout root, content, nav;
    private String page = "welcome";
    private String selectedClient = "Survival Simulator";
    private boolean openServers = true;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        showWelcome();
    }

    private GradientDrawable shape(int color, int stroke) {
        GradientDrawable d = new GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            new int[]{color, darken(color)});
        d.setCornerRadius(dp(18));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private int darken(int c) {
        return Color.rgb((int)(Color.red(c)*0.72), (int)(Color.green(c)*0.72), (int)(Color.blue(c)*0.85));
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); return l;
    }
    private void pad(View v, int all) { v.setPadding(dp(all),dp(all),dp(all),dp(all)); }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }

    private TextView button(String label, Runnable action) {
        TextView b = text(label, 15, Color.WHITE, true);
        b.setGravity(Gravity.CENTER); b.setBackground(shape(PURPLE, Color.rgb(174,143,255)));
        b.setPadding(dp(18), dp(12), dp(18), dp(12));
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private LinearLayout card() {
        LinearLayout c = column(); c.setBackground(shape(PANEL, Color.rgb(85,75,155)));
        pad(c, 16); return c;
    }
    private void shell(String title) {
        root = column(); root.setBackgroundColor(BG);
        setContentView(root);
        LinearLayout header = row(); header.setPadding(dp(18),dp(10),dp(18),dp(10));
        TextView brand = text("◆  OpenSS Launcher", 18, TEXT, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView version = text("v1.0.0", 12, MUTED, false);
        header.addView(version);
        root.addView(header);
        LinearLayout body = row(); body.setPadding(dp(12),dp(4),dp(12),dp(12));
        root.addView(body, new LinearLayout.LayoutParams(-1,0,1));
        nav = column(); nav.setBackground(shape(PANEL, Color.rgb(65,58,125)));
        nav.setPadding(dp(8),dp(10),dp(8),dp(10));
        body.addView(nav, lp(155,-1));
        addNav("⌂   Главная", "home");
        addNav("▤   Новости", "news");
        addNav("⚙   Настройки", "settings");
        ScrollView scroll = new ScrollView(this);
        content = column(); content.setPadding(dp(12),dp(4),dp(8),dp(4));
        scroll.addView(content);
        body.addView(scroll, new LinearLayout.LayoutParams(0,-1,1));
    }
    private void addNav(String label, String target) {
        TextView item = text(label, 14, page.equals(target) ? Color.WHITE : MUTED, true);
        item.setPadding(dp(12),dp(12),dp(8),dp(12));
        if (page.equals(target)) item.setBackground(shape(PURPLE, 0));
        LinearLayout.LayoutParams p = lp(-1,48); p.bottomMargin = dp(6); nav.addView(item,p);
        item.setOnClickListener(v -> { if(target.equals("home")) showHome(); else if(target.equals("settings")) showSettings(); else showNews(); });
    }

    private void showWelcome() {
        page = "welcome";
        root = column(); root.setGravity(Gravity.CENTER); root.setBackground(shape(BG,0)); setContentView(root);
        TextView logo = text("◈", 76, PURPLE, true); logo.setGravity(Gravity.CENTER);
        root.addView(logo, lp(-1,100));
        TextView name = text("OpenSS Launcher", 34, TEXT, true); name.setGravity(Gravity.CENTER);
        root.addView(name);
        TextView sub = text("Играй. Обновляй. Открывай.", 16, MUTED, false); sub.setGravity(Gravity.CENTER);
        root.addView(sub, lp(-1,50));
        TextView start = button("НАЧАТЬ  →", () -> showHome());
        LinearLayout.LayoutParams p = lp(260,54); p.topMargin=dp(28); root.addView(start,p);
    }

    private void showHome() {
        page = "home"; shell("Главная");
        LinearLayout hero = card();
        hero.addView(text("●  ОБНОВЛЕНИЕ ДОСТУПНО", 12, Color.rgb(207,184,255), true));
        hero.addView(text("Версия 1.0.1", 27, TEXT, true), lp(-1,48));
        hero.addView(text("Исправлены ошибки, улучшена производительность и добавлены новые возможности.", 15, MUTED, false));
        LinearLayout.LayoutParams hp = lp(-1,-2); hp.bottomMargin=dp(14); content.addView(hero,hp);
        TextView check = button("⟳  Проверить обновление", () -> toast("Проверка обновлений пока работает как демонстрация"));
        content.addView(check, lp(240,48));
        LinearLayout.LayoutParams gap = lp(-1,16); content.addView(space(),gap);
        content.addView(text("Новости обновлений", 20, TEXT, true), lp(-1,42));
        addNewsCard("Вышло обновление 1.0.1", "Исправлены ошибки и добавлены новые функции.");
        addNewsCard("Добро пожаловать в OpenSS", "Следите за новостями и обновлениями проекта.");
        content.addView(space(), lp(-1,12));
        content.addView(button("ИГРАТЬ  →", () -> showServers()), lp(220,52));
    }
    private View space() { View v=new View(this); return v; }

    private void addNewsCard(String title, String desc) {
        LinearLayout c=card(); c.addView(text(title,16,TEXT,true));
        c.addView(text(desc,13,MUTED,false),lp(-1,32));
        LinearLayout.LayoutParams p=lp(-1,-2); p.bottomMargin=dp(10); content.addView(c,p);
    }
    private void showNews() {
        page="news"; shell("Новости");
        content.addView(text("Новости проекта",24,TEXT,true),lp(-1,52));
        addNewsCard("Обновление 1.0.1","Исправлены ошибки, улучшена производительность.");
        addNewsCard("Новые серверы","Следите за появлением новых игровых миров.");
        addNewsCard("OpenSS Launcher","Открытый проект. Больше возможностей впереди.");
    }
    private void showServers() {
        page="servers"; shell("Серверы");
        content.addView(text("Выбор сервера",24,TEXT,true),lp(-1,48));
        content.addView(text("Клиент: " + selectedClient,14,MUTED,false),lp(-1,34));
        if (!openServers) {
            LinearLayout c=card(); c.addView(text("Серверы OpenSS отключены",18,TEXT,true));
            c.addView(text("Включите их в настройках, чтобы увидеть список.",14,MUTED,false));
            content.addView(c,lp(-1,-2)); return;
        }
        addServer("Survival World #1","Выживание, PvP","32 / 100");
        addServer("Survival World #2","Выживание, без PvP","18 / 100");
        addServer("OpenSS Classic","Классический режим","24 / 100");
        addServer("Community Server","Сообщество","12 / 100");
        content.addView(space(),lp(-1,12));
        content.addView(button("ПОДКЛЮЧИТЬСЯ", () -> toast("Демо: подключение к серверу не настроено")),lp(220,52));
    }
    private void addServer(String name,String desc,String players) {
        LinearLayout c=card(); LinearLayout r=row();
        LinearLayout info=column(); info.addView(text(name,16,TEXT,true)); info.addView(text(desc,12,MUTED,false));
        r.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        r.addView(text("●  "+players,13,Color.rgb(94,230,166),true));
        c.addView(r);
        LinearLayout.LayoutParams p=lp(-1,-2); p.bottomMargin=dp(9); content.addView(c,p);
    }
    private void showSettings() {
        page="settings"; shell("Настройки");
        content.addView(text("Настройки",24,TEXT,true),lp(-1,48));
        LinearLayout serverCard=card(); LinearLayout r=row();
        LinearLayout labels=column(); labels.addView(text("Серверы OpenSS",17,TEXT,true));
        labels.addView(text("Показывать серверы OpenSS в списке",12,MUTED,false));
        r.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        Switch sw=new Switch(this); sw.setChecked(openServers); sw.setButtonTintList(null);
        sw.setOnCheckedChangeListener((b,checked)->openServers=checked);
        r.addView(sw); serverCard.addView(r); content.addView(serverCard,lp(-1,-2));
        content.addView(text("Выбор клиента",19,TEXT,true),lp(-1,52));
        addClient("Survival Simulator","Мир выживания и строительства");
        addClient("OpenSS","Классический клиент с открытым кодом");
        content.addView(space(),lp(-1,12));
        LinearLayout note=card(); note.addView(text("ⓘ  Выбранный клиент будет использоваться при переходе к серверам.",13,MUTED,false));
        content.addView(note,lp(-1,-2));
    }
    private void addClient(String name,String desc) {
        LinearLayout c=card(); LinearLayout r=row();
        LinearLayout labels=column(); labels.addView(text(name,16,TEXT,true)); labels.addView(text(desc,12,MUTED,false));
        r.addView(labels,new LinearLayout.LayoutParams(0,-2,1));
        RadioButton radio=new RadioButton(this); radio.setText(""); radio.setChecked(selectedClient.equals(name));
        radio.setOnClickListener(v->{selectedClient=name; showSettings();});
        r.addView(radio); c.addView(r);
        LinearLayout.LayoutParams p=lp(-1,-2); p.bottomMargin=dp(9); content.addView(c,p);
        c.setOnClickListener(v->{selectedClient=name; showSettings();});
    }
    private void toast(String s) { Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    @Override public void onBackPressed() {
        if(page.equals("servers") || page.equals("settings") || page.equals("news")) showHome();
        else if(page.equals("home")) showWelcome();
        else super.onBackPressed();
    }
}
